import React from 'react'

export default function AssignedTasks() {
  return (
    <div>AssignedTasks</div>
  )
}
