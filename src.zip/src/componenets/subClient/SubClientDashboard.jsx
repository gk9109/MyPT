import React from 'react'

export default function SubClientDashboard() {
  return (
    <div>SubClientDashboard</div>
  )
}
