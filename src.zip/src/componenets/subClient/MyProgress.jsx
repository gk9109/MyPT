import React from 'react'

export default function MyProgress() {
  return (
    <div>MyProgress</div>
  )
}
