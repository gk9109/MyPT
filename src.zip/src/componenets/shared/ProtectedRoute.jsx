// ProtectedRoute.jsx (Outlet version)
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../../firebase/AuthContext";


//the ({ allow }) syntax means we’re receiving props from wherever <ProtectedRoute /> is used.
//{ allow } is object destructuring
export default function ProtectedRoute({ allow }) {
  //useAuth() is a custom hook from AuthContext file.
  //That hook returns an object (e.g., { user, loading, login, logout }).
  //{ user, loading } is object destructuring again, pulling those properties directly.

  //user → contains the logged-in user’s data (like email, role, uid).
  //loading → boolean that’s true while Firebase/AuthContext is checking if a user is logged in.
  const { user, loading } = useAuth(); 

  //useLocation() is a React Router hook that gives you the current URL info.
  //loc is an object like: { pathname: "/coach/profile", search: "", hash: "", state: null, key: "abc123" }
  //This is used so if a user tries to visit a protected page while not logged in, we can remember where they were trying to go.
  const loc = useLocation();

  //While loading is true, we don’t render anything (avoids showing the page or redirecting too early).
  if (loading) return null;

  //if no user logged in --> redirect to /login
  if (!user) return <Navigate to="/login" replace state={{ from: loc }} />;

  //If the allow array exists and the user’s role is not in it, redirect to /.
  //This is the role-based restriction.
  if (allow && !allow.includes(user.role)) return <Navigate to="/" replace />;

  //<Outlet /> is the placeholder where nested routes will appear.
  //Any <Route> declared inside this <ProtectedRoute> in your router will render here if all checks pass.
  return <Outlet />;
}
