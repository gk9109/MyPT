// src/services/users.js
import { db } from "../firebase/config";
import { doc, setDoc, getDoc, updateDoc } from "firebase/firestore";
import { makeUserProfile } from "../Models/user";

// creates and inserts to db a user profile and returns it
export async function createUserProfile({ uid, email, role, firstName, lastName, phone, location }) {
  //sets a doc reference
  const ref = doc(db, "users", uid);
  //creates a user profile
  const profile = makeUserProfile({ uid, email, role, firstName, lastName, phone, location });
  //sets the doc in db
  await setDoc(ref, profile, { merge: false }); // ensure a clean, consistent shape
  //returns user profile
  return profile;
}

//returns profile doc or null if it does not exist
export async function getUserProfile(uid) {
  //sets a doc ref
  const ref = doc(db, "users", uid);
  //gets the doc ref
  const snap = await getDoc(ref);
  //if the doc exists, returns it, it not then null
  return snap.exists() ? snap.data() : null;
}

//updates profile
export async function updateUserProfile(uid, patch) {
  //sets a doc ref
  const ref = doc(db, "users", uid);
  //updates doc
  await updateDoc(ref, patch);
}
