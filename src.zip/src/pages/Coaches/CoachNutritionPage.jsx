import NutritionForm from "./Coaches/NutritionForm";


export default function CoachNutritionPage() {
  return (
    <div className="p-4">
      <NutritionForm />
    </div>
  );
}
