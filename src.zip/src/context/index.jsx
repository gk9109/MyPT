// Temporary shim so old imports keep working.
// Later, delete this file and update imports.
export { AuthProvider, useAuth } from "../firebase/AuthContext";
